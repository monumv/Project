import { Component, OnInit,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-viewemail',
  templateUrl: './viewemail.component.html',
  styleUrls: ['./viewemail.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class ViewemailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
