import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeeledger',
  templateUrl: './employeeledger.component.html',
  styleUrls: ['./employeeledger.component.css']
})
export class EmployeeledgerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
