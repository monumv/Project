import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-template',
  templateUrl: './add-template.component.html',
  styleUrls: ['./add-template.component.css']
})
export class AddTemplateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
