import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-sender-id',
  templateUrl: './add-sender-id.component.html',
  styleUrls: ['./add-sender-id.component.css']
})
export class AddSenderIdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
