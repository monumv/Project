import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dlt-management',
  templateUrl: './dlt-management.component.html',
  styleUrls: ['./dlt-management.component.css']
})
export class DltManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
