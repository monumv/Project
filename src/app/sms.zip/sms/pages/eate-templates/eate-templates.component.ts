import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eate-templates',
  templateUrl: './eate-templates.component.html',
  styleUrls: ['./eate-templates.component.css']
})
export class EateTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
