import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-operator',
  templateUrl: './add-operator.component.html',
  styleUrls: ['./add-operator.component.css']
})
export class AddOperatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
