import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-entity-id',
  templateUrl: './add-entity-id.component.html',
  styleUrls: ['./add-entity-id.component.css']
})
export class AddEntityIdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
