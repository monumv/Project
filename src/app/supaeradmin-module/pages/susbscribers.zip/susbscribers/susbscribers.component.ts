import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-susbscribers',
  templateUrl: './susbscribers.component.html',
  styleUrls: ['./susbscribers.component.css']
})
export class SusbscribersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
